import Foundation

struct APIError: Error, LocalizedError {
    let message: String
    let statusCode: Int?

    init(message: String, statusCode: Int? = nil) {
        self.message = message
        self.statusCode = statusCode
    }

    var errorDescription: String? {
        message
    }
}

private struct APIErrorEnvelope: Decodable {
    let message: String?
}

private struct SupabaseAuthErrorEnvelope: Decodable {
    let msg: String?
    let error_description: String?
    let error: String?
}

private struct EmptyResponse: Codable {}

private struct AnyEncodable: Encodable {
    private let encodeFunc: (Encoder) throws -> Void

    init<T: Encodable>(_ wrapped: T) {
        self.encodeFunc = wrapped.encode(to:)
    }

    func encode(to encoder: Encoder) throws {
        try encodeFunc(encoder)
    }
}

enum HTTPMethod: String {
    case GET
    case POST
    case PUT
    case PATCH
    case DELETE
}

// MARK: - DTOs

struct MobileAuthUserDTO: Decodable {
    let id: String
    let email: String?
    let user_metadata: [String: StringOrBoolOrNumber]?
}

struct MobileAuthSessionDTO: Decodable {
    let access_token: String?
    let refresh_token: String?
    let expires_at: Int?
    let user: MobileAuthUserDTO?
    let profile: ProfileDTO?
    let is_host: Bool?
    let host_status: String?
    let requires_email_confirmation: Bool?
}

struct MobileMeDTO: Decodable {
    let user: MobileAuthUserDTO
    let profile: ProfileDTO?
    let is_host: Bool
    let host_status: String?
    let host_application: HostApplicationDTO?
}

struct ProfileDTO: Decodable {
    let id: String?
    let first_name: String?
    let last_name: String?
    let full_name: String?
    let email: String?
    let phone: String?
    let city: String?
    let region: String?
    let avatar_url: String?
    let is_host: Bool?
    let id_verified: Bool?
    let phone_verified: Bool?
    let email_verified: Bool?
    let host_level: String?
}

struct CarsEnvelopeDTO: Decodable {
    let data: [CarDTO]
}

struct CarDetailEnvelopeDTO: Decodable {
    let data: CarDTO
}

struct CarDTO: Decodable {
    let id: String
    let owner_id: String?
    let title: String?
    let description: String?
    let brand: String?
    let model: String?
    let daily_price: DoubleOrIntOrString?
    let city: String?
    let region: String?
    let car_type: String?
    let seats: DoubleOrIntOrString?
    let transmission: String?
    let fuel_type: String?
    let features: [String]?
    let year: DoubleOrIntOrString?
    let car_year: DoubleOrIntOrString?
    let delivery_fee: DoubleOrIntOrString?
    let insurance_fee: DoubleOrIntOrString?
    let deposit_amount: DoubleOrIntOrString?
    let outside_accra_fee: DoubleOrIntOrString?
    let cancellation_policy: String?
    let is_available: Bool?
    let instant_book: Bool?
    let delivery_available: Bool?
    let air_conditioning: Bool?
    let approval_status: String?
    let created_at: String?
    let avg_rating: DoubleOrIntOrString?
    let reviews_count: DoubleOrIntOrString?
    let favorites_count: DoubleOrIntOrString?
    let host_name: String?
    let host_avatar: String?
    let host_level: String?
    let id_verified: Bool?
    let phone_verified: Bool?
    let email_verified: Bool?
    let image_url: String?
    let car_photos: [CarPhotoDTO]?
    let owner: ProfileDTO?
}

struct CarPhotoDTO: Decodable {
    let url: String?
}

struct FavoritesEnvelopeDTO: Decodable {
    let data: [FavoriteDTO]
}

struct FavoriteDTO: Decodable {
    let car_id: String
}

struct BookingsEnvelopeDTO: Decodable {
    let data: [BookingDTO]
}

struct BookingHoldDTO: Decodable {
    let bookingId: String
    let hold_expires_at: String?
}

struct BookingDTO: Decodable {
    let id: String
    let car_id: String?
    let renter_id: String?
    let start_date: String?
    let end_date: String?
    let status: String?
    let payment_status: String?
    let total_price: DoubleOrIntOrString?
    let trip_use_region: String?
    let trip_use_city: String?
    let trip_use_address: String?
    let trip_outside_accra: Bool?
    let daily_rate: DoubleOrIntOrString?
    let subtotal: DoubleOrIntOrString?
    let platform_fee: DoubleOrIntOrString?
    let insurance_fee: DoubleOrIntOrString?
    let delivery_fee: DoubleOrIntOrString?
    let outside_accra_surcharge: DoubleOrIntOrString?
    let deposit_amount: DoubleOrIntOrString?
    let payment_reference: String?
    let rejection_reason: String?
    let created_at: String?
    let conversation_id: String?
    let cars: BookingCarDTO?
    let renter: BookingRenterDTO?
}

struct BookingCarDTO: Decodable {
    let id: String?
    let title: String?
    let owner_id: String?
    let owner: ProfileDTO?
}

struct BookingRenterDTO: Decodable {
    let id: String?
    let full_name: String?
}

struct HostStatusDTO: Decodable {
    let is_host: Bool
    let status: String?
}

struct HostApplicationEnvelopeDTO: Decodable {
    let data: HostApplicationDTO?
}

struct HostApplicationDTO: Decodable {
    let id: String?
    let status: String?
    let full_name: String?
    let phone: String?
    let region: String?
    let city: String?
    let id_type: String?
    let id_number: String?
    let experience: String?
    let fleet_size: DoubleOrIntOrString?
    let note: String?
    let rejection_reason: String?
}

struct ConversationsEnvelopeDTO: Decodable {
    let data: [ConversationDTO]
}

struct ConversationDTO: Decodable {
    let id: String
    let host_id: String
    let user_id: String
    let car_id: String?
    let booking_id: String?
    let created_at: String?
    let last_message_at: String?
    let last_message_preview: String?
    let unread_count: Int?
    let other_user: ConversationUserDTO?
}

struct ConversationUserDTO: Decodable {
    let id: String?
    let name: String?
    let avatar: String?
}

struct MessagesEnvelopeDTO: Decodable {
    let data: [MessageDTO]
}

struct MessageEnvelopeDTO: Decodable {
    let data: MessageDTO
}

struct MessageDTO: Decodable {
    let id: String
    let conversation_id: String
    let sender_id: String
    let body: String
    let created_at: String
    let read_at: String?
}

struct ConversationCreateDTO: Decodable {
    let id: String
}

struct ReviewsEnvelopeDTO: Decodable {
    let data: [ReviewDTO]
}

struct ReviewMutationEnvelopeDTO: Decodable {
    let data: ReviewDTO?
}

struct ReviewDTO: Decodable {
    let id: String
    let car_id: String?
    let rating: DoubleOrIntOrString?
    let comment: String?
    let created_at: String?
    let cars: ReviewCarDTO?
    let reviewer: ReviewUserDTO?
}

struct ReviewCarDTO: Decodable {
    let title: String?
}

struct ReviewUserDTO: Decodable {
    let full_name: String?
}

private struct SupabaseConversationRowDTO: Decodable {
    let id: String
    let host_id: String
    let user_id: String
    let car_id: String?
    let booking_id: String?
    let created_at: String?
    let last_message_at: String?
    let last_message_preview: String?
}

private struct SupabaseProfileLiteDTO: Decodable {
    let id: String
    let full_name: String?
    let avatar_url: String?
}

private struct SupabaseConversationIDDTO: Decodable {
    let id: String
}

private struct SupabaseUnreadConversationDTO: Decodable {
    let conversation_id: String
}

struct CarMutationEnvelopeDTO: Decodable {
    let data: CarDTO
}

private struct SupabaseSessionResponseDTO: Decodable {
    let access_token: String?
    let refresh_token: String?
    let expires_at: Int?
    let expires_in: Int?
    let user: MobileAuthUserDTO?
}

private struct SupabaseSignupResponseDTO: Decodable {
    let access_token: String?
    let refresh_token: String?
    let expires_at: Int?
    let expires_in: Int?
    let user: MobileAuthUserDTO?
    let session: SupabaseSessionResponseDTO?
    let id: String?
    let email: String?
    let user_metadata: [String: StringOrBoolOrNumber]?
}

struct APIClient {
    static let shared = APIClient()

    private let decoder: JSONDecoder
    private let encoder: JSONEncoder
    private let session: URLSession

    private init() {
        self.decoder = JSONDecoder()
        self.encoder = JSONEncoder()
        let configuration = URLSessionConfiguration.default
        configuration.waitsForConnectivity = true
        configuration.timeoutIntervalForRequest = 20
        configuration.timeoutIntervalForResource = 60
        configuration.httpMaximumConnectionsPerHost = 10
        self.session = URLSession(configuration: configuration)
    }

    private struct SupabaseConfig {
        let url: String
        let anonKey: String
    }

    // MARK: - Mobile Auth

    func login(baseURL: String, email: String, password: String) async throws -> MobileAuthSessionDTO {
        struct Payload: Encodable {
            let email: String
            let password: String
        }
        do {
            return try await request(
                path: "/api/mobile/auth/login",
                method: .POST,
                body: Payload(email: email, password: password),
                baseURL: baseURL,
                token: nil
            )
        } catch let apiError as APIError {
            if apiError.statusCode == 404 {
                return try await loginWithSupabase(email: email, password: password)
            }
            throw apiError
        }
    }

    func signup(
        baseURL: String,
        firstName: String,
        lastName: String,
        email: String,
        password: String,
        city: String,
        region: String
    ) async throws -> MobileAuthSessionDTO {
        struct Payload: Encodable {
            let first_name: String
            let last_name: String
            let email: String
            let password: String
            let city: String
            let region: String
        }
        do {
            return try await request(
                path: "/api/mobile/auth/signup",
                method: .POST,
                body: Payload(
                    first_name: firstName,
                    last_name: lastName,
                    email: email,
                    password: password,
                    city: city,
                    region: region
                ),
                baseURL: baseURL,
                token: nil
            )
        } catch let apiError as APIError {
            if apiError.statusCode == 404 {
                return try await signupWithSupabase(
                    firstName: firstName,
                    lastName: lastName,
                    email: email,
                    password: password,
                    city: city,
                    region: region
                )
            }
            throw apiError
        }
    }

    func refreshToken(baseURL: String, refreshToken: String) async throws -> MobileAuthSessionDTO {
        struct Payload: Encodable {
            let refresh_token: String
        }
        do {
            return try await request(
                path: "/api/mobile/auth/refresh",
                method: .POST,
                body: Payload(refresh_token: refreshToken),
                baseURL: baseURL,
                token: nil
            )
        } catch let apiError as APIError {
            if apiError.statusCode == 404 {
                return try await refreshWithSupabase(refreshToken: refreshToken)
            }
            throw apiError
        }
    }

    func getMe(baseURL: String, token: String) async throws -> MobileMeDTO {
        do {
            return try await request(path: "/api/mobile/me", method: .GET, body: nil as EmptyResponse?, baseURL: baseURL, token: token)
        } catch let apiError as APIError {
            if apiError.statusCode == 404 {
                return try await getMeWithSupabase(baseURL: baseURL, token: token)
            }
            throw apiError
        }
    }

    // MARK: - Cars

    func getCars(baseURL: String, token: String?) async throws -> CarsEnvelopeDTO {
        try await request(path: "/api/cars", method: .GET, body: nil as EmptyResponse?, baseURL: baseURL, token: token)
    }

    func getCarDetail(baseURL: String, token: String?, carID: String) async throws -> CarDetailEnvelopeDTO {
        let encodedCarID = carID.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? carID
        return try await request(
            path: "/api/cars/\(encodedCarID)",
            method: .GET,
            body: nil as EmptyResponse?,
            baseURL: baseURL,
            token: token
        )
    }

    func getMyCars(baseURL: String, token: String) async throws -> CarsEnvelopeDTO {
        try await request(path: "/api/cars?mine=1&limit=200", method: .GET, body: nil as EmptyResponse?, baseURL: baseURL, token: token)
    }

    func createCar(baseURL: String, token: String, payload: [String: Any]) async throws -> CarMutationEnvelopeDTO {
        try await requestJSON(path: "/api/cars", method: .POST, json: payload, baseURL: baseURL, token: token)
    }

    func updateCar(baseURL: String, token: String, carID: String, payload: [String: Any]) async throws -> CarMutationEnvelopeDTO {
        try await requestJSON(path: "/api/cars/\(carID)", method: .PUT, json: payload, baseURL: baseURL, token: token)
    }

    func deleteCar(baseURL: String, token: String, carID: String) async throws {
        _ = try await request(path: "/api/cars/\(carID)", method: .DELETE, body: nil as EmptyResponse?, baseURL: baseURL, token: token) as EmptyResponse
    }

    // MARK: - Favorites

    func getFavorites(baseURL: String, token: String) async throws -> FavoritesEnvelopeDTO {
        do {
            return try await request(path: "/api/favorites", method: .GET, body: nil as EmptyResponse?, baseURL: baseURL, token: token)
        } catch let apiError as APIError {
            if shouldFallbackToSupabase(apiError) || apiError.statusCode == 401 {
                return try await getFavoritesWithSupabase(token: token)
            }
            throw apiError
        }
    }

    func setFavorite(baseURL: String, token: String, carID: String, isFavorite: Bool) async throws {
        struct Payload: Encodable {
            let carId: String
            let isFavorite: Bool
        }
        do {
            _ = try await request(
                path: "/api/favorites",
                method: .POST,
                body: Payload(carId: carID, isFavorite: isFavorite),
                baseURL: baseURL,
                token: token
            ) as EmptyResponse
        } catch let apiError as APIError {
            if shouldFallbackToSupabase(apiError) || apiError.statusCode == 401 {
                try await setFavoriteWithSupabase(token: token, carID: carID, isFavorite: isFavorite)
                return
            }
            throw apiError
        }
    }

    // MARK: - Profile

    func upsertProfile(
        baseURL: String,
        token: String,
        userID: String,
        firstName: String,
        lastName: String,
        fullName: String,
        city: String,
        region: String,
        phone: String,
        avatarURL: String?
    ) async throws {
        struct Payload: Encodable {
            let id: String
            let first_name: String
            let last_name: String
            let full_name: String
            let city: String
            let region: String
            let phone: String
            let avatar_url: String?
        }

        _ = try await request(
            path: "/api/profiles/upsert",
            method: .POST,
            body: Payload(
                id: userID,
                first_name: firstName,
                last_name: lastName,
                full_name: fullName,
                city: city,
                region: region,
                phone: phone,
                avatar_url: avatarURL
            ),
            baseURL: baseURL,
            token: token
        ) as EmptyResponse
    }

    // MARK: - Bookings

    func getBookings(baseURL: String, token: String) async throws -> BookingsEnvelopeDTO {
        try await request(path: "/api/bookings", method: .GET, body: nil as EmptyResponse?, baseURL: baseURL, token: token)
    }

    func createBookingHold(
        baseURL: String,
        token: String,
        carID: String,
        startDate: String,
        endDate: String,
        tripUseRegion: String,
        tripUseCity: String,
        tripUseAddress: String
    ) async throws -> BookingHoldDTO {
        struct Payload: Encodable {
            let carId: String
            let startDate: String
            let endDate: String
            let tripUseRegion: String
            let tripUseCity: String
            let tripUseAddress: String
        }

        return try await request(
            path: "/api/bookings/hold",
            method: .POST,
            body: Payload(
                carId: carID,
                startDate: startDate,
                endDate: endDate,
                tripUseRegion: tripUseRegion,
                tripUseCity: tripUseCity,
                tripUseAddress: tripUseAddress
            ),
            baseURL: baseURL,
            token: token
        )
    }

    func updateBookingDecision(baseURL: String, token: String, bookingID: String, approve: Bool) async throws {
        struct Payload: Encodable {
            let action: String
        }
        _ = try await request(
            path: "/api/bookings/\(bookingID)",
            method: .PATCH,
            body: Payload(action: approve ? "approve" : "reject"),
            baseURL: baseURL,
            token: token
        ) as EmptyResponse
    }

    func createDispute(baseURL: String, token: String, bookingID: String, reason: String) async throws {
        struct Payload: Encodable {
            let bookingId: String
            let reason: String
        }
        _ = try await request(
            path: "/api/disputes",
            method: .POST,
            body: Payload(bookingId: bookingID, reason: reason),
            baseURL: baseURL,
            token: token
        ) as EmptyResponse
    }

    func submitReview(baseURL: String, token: String, bookingID: String, rating: Int, comment: String) async throws -> ReviewMutationEnvelopeDTO {
        struct Payload: Encodable {
            let bookingId: String
            let rating: Int
            let comment: String
        }

        return try await request(
            path: "/api/reviews",
            method: .POST,
            body: Payload(bookingId: bookingID, rating: rating, comment: comment),
            baseURL: baseURL,
            token: token
        )
    }

    // MARK: - Host

    func getHostStatus(baseURL: String, token: String) async throws -> HostStatusDTO {
        try await request(path: "/api/host-status", method: .GET, body: nil as EmptyResponse?, baseURL: baseURL, token: token)
    }

    func getHostApplication(baseURL: String, token: String) async throws -> HostApplicationEnvelopeDTO {
        try await request(path: "/api/host-applications", method: .GET, body: nil as EmptyResponse?, baseURL: baseURL, token: token)
    }

    func submitHostApplication(baseURL: String, token: String, payload: [String: Any]) async throws -> HostApplicationEnvelopeDTO {
        try await requestJSON(path: "/api/host-applications", method: .POST, json: payload, baseURL: baseURL, token: token)
    }

    func getHostReviews(baseURL: String, token: String) async throws -> ReviewsEnvelopeDTO {
        try await request(path: "/api/reviews?scope=host", method: .GET, body: nil as EmptyResponse?, baseURL: baseURL, token: token)
    }

    // MARK: - Messaging

    func getConversations(baseURL: String, token: String) async throws -> ConversationsEnvelopeDTO {
        do {
            return try await request(path: "/api/conversations", method: .GET, body: nil as EmptyResponse?, baseURL: baseURL, token: token)
        } catch let apiError as APIError {
            if shouldFallbackToSupabase(apiError) {
                return try await getConversationsWithSupabase(token: token)
            }
            throw apiError
        }
    }

    func createConversation(baseURL: String, token: String, payload: [String: Any]) async throws -> ConversationCreateDTO {
        do {
            return try await requestJSON(path: "/api/conversations", method: .POST, json: payload, baseURL: baseURL, token: token)
        } catch let apiError as APIError {
            if shouldFallbackToSupabase(apiError) {
                return try await createConversationWithSupabase(token: token, payload: payload)
            }
            throw apiError
        }
    }

    func getMessages(baseURL: String, token: String, conversationID: String, markRead: Bool = true) async throws -> MessagesEnvelopeDTO {
        let encodedConversation = conversationID.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? conversationID
        let mark = markRead ? "1" : "0"
        do {
            return try await request(
                path: "/api/messages?conversationId=\(encodedConversation)&markRead=\(mark)",
                method: .GET,
                body: nil as EmptyResponse?,
                baseURL: baseURL,
                token: token
            )
        } catch let apiError as APIError {
            if shouldFallbackToSupabase(apiError) {
                return try await getMessagesWithSupabase(token: token, conversationID: conversationID, markRead: markRead)
            }
            throw apiError
        }
    }

    func sendMessage(baseURL: String, token: String, conversationID: String, body: String) async throws -> MessageEnvelopeDTO {
        struct Payload: Encodable {
            let conversationId: String
            let body: String
        }
        do {
            return try await request(
                path: "/api/messages",
                method: .POST,
                body: Payload(conversationId: conversationID, body: body),
                baseURL: baseURL,
                token: token
            )
        } catch let apiError as APIError {
            if shouldFallbackToSupabase(apiError) {
                return try await sendMessageWithSupabase(token: token, conversationID: conversationID, body: body)
            }
            throw apiError
        }
    }

    // MARK: - Push

    func registerPushToken(baseURL: String, token: String, deviceToken: String) async throws {
        struct Payload: Encodable {
            let deviceToken: String
            let platform: String
        }
        _ = try await request(
            path: "/api/mobile/push/register",
            method: .POST,
            body: Payload(deviceToken: deviceToken, platform: "ios"),
            baseURL: baseURL,
            token: token
        ) as EmptyResponse
    }

    // MARK: - HTTP

    private func loadSupabaseConfig() throws -> SupabaseConfig {
        let rawURL = (Bundle.main.object(forInfoDictionaryKey: "HAYAMESupabaseURL") as? String)?
            .trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        let anonKey = (Bundle.main.object(forInfoDictionaryKey: "HAYAMESupabaseAnonKey") as? String)?
            .trimmingCharacters(in: .whitespacesAndNewlines) ?? ""

        guard !rawURL.isEmpty, !anonKey.isEmpty else {
            throw APIError(
                message: "Mobile auth route is not deployed on this server yet. Deploy latest backend or configure Supabase keys in app settings.",
                statusCode: 404
            )
        }

        return SupabaseConfig(url: normalizeBaseURL(rawURL), anonKey: anonKey)
    }

    private func resolvedExpiresAt(expiresAt: Int?, expiresIn: Int?) -> Int? {
        if let expiresAt {
            return expiresAt
        }
        if let expiresIn {
            return Int(Date().timeIntervalSince1970) + expiresIn
        }
        return nil
    }

    private func executeSupabaseRequest(
        url: URL,
        method: HTTPMethod,
        body: Data?,
        config: SupabaseConfig,
        bearer: String? = nil,
        additionalHeaders: [String: String] = [:]
    ) async throws -> (Data, HTTPURLResponse) {
        var request = URLRequest(url: url)
        request.httpMethod = method.rawValue
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue(config.anonKey, forHTTPHeaderField: "apikey")
        request.setValue("Bearer \(bearer ?? config.anonKey)", forHTTPHeaderField: "Authorization")
        for (key, value) in additionalHeaders {
            request.setValue(value, forHTTPHeaderField: key)
        }
        request.httpBody = body

        let (data, response) = try await session.data(for: request)
        guard let http = response as? HTTPURLResponse else {
            throw APIError(message: "Invalid server response")
        }
        guard (200...299).contains(http.statusCode) else {
            let message =
                decodeError(
                    from: data,
                    statusCode: http.statusCode,
                    contentType: http.value(forHTTPHeaderField: "Content-Type")
                ) ?? "Request failed with status \(http.statusCode)"
            throw APIError(message: message, statusCode: http.statusCode)
        }
        return (data, http)
    }

    private func loginWithSupabase(email: String, password: String) async throws -> MobileAuthSessionDTO {
        let config = try loadSupabaseConfig()
        guard let url = URL(string: "\(config.url)/auth/v1/token?grant_type=password") else {
            throw APIError(message: "Invalid Supabase URL")
        }

        let body = try JSONSerialization.data(withJSONObject: [
            "email": email,
            "password": password
        ])
        let (data, _) = try await executeSupabaseRequest(url: url, method: .POST, body: body, config: config)
        let session = try decoder.decode(SupabaseSessionResponseDTO.self, from: data)

        return MobileAuthSessionDTO(
            access_token: session.access_token,
            refresh_token: session.refresh_token,
            expires_at: resolvedExpiresAt(expiresAt: session.expires_at, expiresIn: session.expires_in),
            user: session.user,
            profile: nil,
            is_host: nil,
            host_status: nil,
            requires_email_confirmation: false
        )
    }

    private func signupWithSupabase(
        firstName: String,
        lastName: String,
        email: String,
        password: String,
        city: String,
        region: String
    ) async throws -> MobileAuthSessionDTO {
        let config = try loadSupabaseConfig()
        guard let url = URL(string: "\(config.url)/auth/v1/signup") else {
            throw APIError(message: "Invalid Supabase URL")
        }

        let body = try JSONSerialization.data(withJSONObject: [
            "email": email,
            "password": password,
            "data": [
                "first_name": firstName,
                "last_name": lastName,
                "full_name": "\(firstName) \(lastName)".trimmingCharacters(in: .whitespacesAndNewlines),
                "city": city,
                "region": region
            ]
        ])
        let (data, _) = try await executeSupabaseRequest(url: url, method: .POST, body: body, config: config)
        let response = try decoder.decode(SupabaseSignupResponseDTO.self, from: data)

        let nestedSession = response.session
        let user =
            response.user ??
            nestedSession?.user ??
            {
                guard let id = response.id else { return nil }
                return MobileAuthUserDTO(id: id, email: response.email, user_metadata: response.user_metadata)
            }()
        let accessToken = response.access_token ?? nestedSession?.access_token
        let refreshToken = response.refresh_token ?? nestedSession?.refresh_token
        let expiresAt = resolvedExpiresAt(
            expiresAt: response.expires_at ?? nestedSession?.expires_at,
            expiresIn: response.expires_in ?? nestedSession?.expires_in
        )
        let requiresConfirmation = accessToken == nil || user == nil

        return MobileAuthSessionDTO(
            access_token: accessToken,
            refresh_token: refreshToken,
            expires_at: expiresAt,
            user: user,
            profile: nil,
            is_host: nil,
            host_status: nil,
            requires_email_confirmation: requiresConfirmation
        )
    }

    private func refreshWithSupabase(refreshToken: String) async throws -> MobileAuthSessionDTO {
        let config = try loadSupabaseConfig()
        guard let url = URL(string: "\(config.url)/auth/v1/token?grant_type=refresh_token") else {
            throw APIError(message: "Invalid Supabase URL")
        }

        let body = try JSONSerialization.data(withJSONObject: [
            "refresh_token": refreshToken
        ])
        let (data, _) = try await executeSupabaseRequest(url: url, method: .POST, body: body, config: config)
        let session = try decoder.decode(SupabaseSessionResponseDTO.self, from: data)

        return MobileAuthSessionDTO(
            access_token: session.access_token,
            refresh_token: session.refresh_token,
            expires_at: resolvedExpiresAt(expiresAt: session.expires_at, expiresIn: session.expires_in),
            user: session.user,
            profile: nil,
            is_host: nil,
            host_status: nil,
            requires_email_confirmation: false
        )
    }

    private func getMeWithSupabase(baseURL: String, token: String) async throws -> MobileMeDTO {
        let config = try loadSupabaseConfig()
        guard let url = URL(string: "\(config.url)/auth/v1/user") else {
            throw APIError(message: "Invalid Supabase URL")
        }

        let (data, _) = try await executeSupabaseRequest(
            url: url,
            method: .GET,
            body: nil,
            config: config,
            bearer: token
        )
        let user = try decoder.decode(MobileAuthUserDTO.self, from: data)
        let hostStatus = try? await getHostStatus(baseURL: baseURL, token: token)

        return MobileMeDTO(
            user: user,
            profile: nil,
            is_host: hostStatus?.is_host ?? false,
            host_status: hostStatus?.status,
            host_application: nil
        )
    }

    private func shouldFallbackToSupabase(_ apiError: APIError) -> Bool {
        guard let statusCode = apiError.statusCode else { return false }
        return statusCode == 404 || statusCode == 405
    }

    private func getConversationsWithSupabase(token: String) async throws -> ConversationsEnvelopeDTO {
        guard let currentUserID = decodeJWTSubject(token) else {
            throw APIError(message: "Unable to resolve current user session.")
        }
        let config = try loadSupabaseConfig()
        let conversationsURL = try restURL(
            config: config,
            table: "conversations",
            queryItems: [
                URLQueryItem(name: "select", value: "id,host_id,user_id,car_id,booking_id,created_at,last_message_at,last_message_preview"),
                URLQueryItem(name: "or", value: "(host_id.eq.\(currentUserID),user_id.eq.\(currentUserID))")
            ]
        )
        let (conversationData, _) = try await executeSupabaseRequest(
            url: conversationsURL,
            method: .GET,
            body: nil,
            config: config,
            bearer: token
        )
        let rows = try decoder.decode([SupabaseConversationRowDTO].self, from: conversationData)

        let otherUserIDs = Array(
            Set(
                rows.map { row in
                    row.host_id == currentUserID ? row.user_id : row.host_id
                }
            )
        )

        var profileByID: [String: SupabaseProfileLiteDTO] = [:]
        if !otherUserIDs.isEmpty {
            let profilesURL = try restURL(
                config: config,
                table: "profiles",
                queryItems: [
                    URLQueryItem(name: "select", value: "id,full_name,avatar_url"),
                    URLQueryItem(name: "id", value: "in.(\(inFilterValues(otherUserIDs)))")
                ]
            )
            let (profileData, _) = try await executeSupabaseRequest(
                url: profilesURL,
                method: .GET,
                body: nil,
                config: config,
                bearer: token
            )
            let profiles = try decoder.decode([SupabaseProfileLiteDTO].self, from: profileData)
            profileByID = Dictionary(uniqueKeysWithValues: profiles.map { ($0.id, $0) })
        }

        var unreadByConversation: [String: Int] = [:]
        let conversationIDs = rows.map(\.id)
        if !conversationIDs.isEmpty {
            let unreadURL = try restURL(
                config: config,
                table: "messages",
                queryItems: [
                    URLQueryItem(name: "select", value: "conversation_id"),
                    URLQueryItem(name: "conversation_id", value: "in.(\(inFilterValues(conversationIDs)))"),
                    URLQueryItem(name: "read_at", value: "is.null"),
                    URLQueryItem(name: "sender_id", value: "neq.\(currentUserID)")
                ]
            )
            let (unreadData, _) = try await executeSupabaseRequest(
                url: unreadURL,
                method: .GET,
                body: nil,
                config: config,
                bearer: token
            )
            let unreadRows = try decoder.decode([SupabaseUnreadConversationDTO].self, from: unreadData)
            for unread in unreadRows {
                unreadByConversation[unread.conversation_id, default: 0] += 1
            }
        }

        let mapped = rows.map { row -> ConversationDTO in
            let otherID = row.host_id == currentUserID ? row.user_id : row.host_id
            let profile = profileByID[otherID]

            return ConversationDTO(
                id: row.id,
                host_id: row.host_id,
                user_id: row.user_id,
                car_id: row.car_id,
                booking_id: row.booking_id,
                created_at: row.created_at,
                last_message_at: row.last_message_at,
                last_message_preview: row.last_message_preview,
                unread_count: unreadByConversation[row.id] ?? 0,
                other_user: ConversationUserDTO(
                    id: profile?.id ?? otherID,
                    name: profile?.full_name ?? "User",
                    avatar: profile?.avatar_url
                )
            )
        }

        return ConversationsEnvelopeDTO(data: mapped)
    }

    private func createConversationWithSupabase(token: String, payload: [String: Any]) async throws -> ConversationCreateDTO {
        guard let currentUserID = decodeJWTSubject(token) else {
            throw APIError(message: "Unable to resolve current user session.")
        }
        guard
            let hostIDRaw = payload["hostId"] as? String,
            !hostIDRaw.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
        else {
            throw APIError(message: "Missing hostId.")
        }

        let hostID = hostIDRaw.trimmingCharacters(in: .whitespacesAndNewlines)
        let participantID = (payload["participantId"] as? String)?
            .trimmingCharacters(in: .whitespacesAndNewlines)
        let carID = (payload["carId"] as? String)?
            .trimmingCharacters(in: .whitespacesAndNewlines)
        let resolvedUserID = (participantID?.isEmpty == false ? participantID : nil) ?? currentUserID

        if resolvedUserID == hostID {
            throw APIError(message: "Cannot message yourself.")
        }

        let config = try loadSupabaseConfig()
        var existingQueryItems: [URLQueryItem] = [
            URLQueryItem(name: "select", value: "id"),
            URLQueryItem(name: "host_id", value: "eq.\(hostID)"),
            URLQueryItem(name: "user_id", value: "eq.\(resolvedUserID)"),
            URLQueryItem(name: "limit", value: "1")
        ]
        if let carID, !carID.isEmpty {
            existingQueryItems.append(URLQueryItem(name: "car_id", value: "eq.\(carID)"))
        } else {
            existingQueryItems.append(URLQueryItem(name: "car_id", value: "is.null"))
        }

        let existingURL = try restURL(config: config, table: "conversations", queryItems: existingQueryItems)
        let (existingData, _) = try await executeSupabaseRequest(
            url: existingURL,
            method: .GET,
            body: nil,
            config: config,
            bearer: token
        )
        let existingRows = try decoder.decode([SupabaseConversationIDDTO].self, from: existingData)
        if let existing = existingRows.first {
            return ConversationCreateDTO(id: existing.id)
        }

        var insertPayload: [String: Any] = [
            "host_id": hostID,
            "user_id": resolvedUserID
        ]
        insertPayload["car_id"] = (carID?.isEmpty == false ? carID : nil) ?? NSNull()
        let insertData = try JSONSerialization.data(withJSONObject: insertPayload)

        let insertURL = try restURL(
            config: config,
            table: "conversations",
            queryItems: [URLQueryItem(name: "select", value: "id")]
        )
        let (createdData, _) = try await executeSupabaseRequest(
            url: insertURL,
            method: .POST,
            body: insertData,
            config: config,
            bearer: token,
            additionalHeaders: ["Prefer": "return=representation"]
        )
        let createdRows = try decoder.decode([SupabaseConversationIDDTO].self, from: createdData)
        guard let created = createdRows.first else {
            throw APIError(message: "Unable to create conversation.")
        }
        return ConversationCreateDTO(id: created.id)
    }

    private func getMessagesWithSupabase(token: String, conversationID: String, markRead: Bool) async throws -> MessagesEnvelopeDTO {
        let config = try loadSupabaseConfig()
        let messagesURL = try restURL(
            config: config,
            table: "messages",
            queryItems: [
                URLQueryItem(name: "select", value: "id,conversation_id,sender_id,body,created_at,read_at"),
                URLQueryItem(name: "conversation_id", value: "eq.\(conversationID)"),
                URLQueryItem(name: "order", value: "created_at.asc"),
                URLQueryItem(name: "limit", value: "500")
            ]
        )
        let (messagesData, _) = try await executeSupabaseRequest(
            url: messagesURL,
            method: .GET,
            body: nil,
            config: config,
            bearer: token
        )
        let messages = try decoder.decode([MessageDTO].self, from: messagesData)

        if markRead, let currentUserID = decodeJWTSubject(token) {
            let markReadBody = try JSONSerialization.data(withJSONObject: ["read_at": ISO8601DateFormatter().string(from: Date())])
            let markReadURL = try restURL(
                config: config,
                table: "messages",
                queryItems: [
                    URLQueryItem(name: "conversation_id", value: "eq.\(conversationID)"),
                    URLQueryItem(name: "read_at", value: "is.null"),
                    URLQueryItem(name: "sender_id", value: "neq.\(currentUserID)")
                ]
            )
            _ = try await executeSupabaseRequest(
                url: markReadURL,
                method: .PATCH,
                body: markReadBody,
                config: config,
                bearer: token,
                additionalHeaders: ["Prefer": "return=minimal"]
            )
        }

        return MessagesEnvelopeDTO(data: messages)
    }

    private func sendMessageWithSupabase(token: String, conversationID: String, body: String) async throws -> MessageEnvelopeDTO {
        guard let currentUserID = decodeJWTSubject(token) else {
            throw APIError(message: "Unable to resolve current user session.")
        }

        let config = try loadSupabaseConfig()
        let sendPayload: [String: Any] = [
            "conversation_id": conversationID,
            "sender_id": currentUserID,
            "body": body
        ]
        let sendBodyData = try JSONSerialization.data(withJSONObject: sendPayload)

        let sendURL = try restURL(
            config: config,
            table: "messages",
            queryItems: [URLQueryItem(name: "select", value: "id,conversation_id,sender_id,body,created_at,read_at")]
        )
        let (createdData, _) = try await executeSupabaseRequest(
            url: sendURL,
            method: .POST,
            body: sendBodyData,
            config: config,
            bearer: token,
            additionalHeaders: ["Prefer": "return=representation"]
        )
        let createdRows = try decoder.decode([MessageDTO].self, from: createdData)
        guard let message = createdRows.first else {
            throw APIError(message: "Unable to send message.")
        }

        let preview = String(body.prefix(240))
        let updatePayload: [String: Any] = [
            "last_message_at": message.created_at,
            "last_message_preview": preview
        ]
        let updateBodyData = try JSONSerialization.data(withJSONObject: updatePayload)
        let updateURL = try restURL(
            config: config,
            table: "conversations",
            queryItems: [URLQueryItem(name: "id", value: "eq.\(conversationID)")]
        )
        _ = try await executeSupabaseRequest(
            url: updateURL,
            method: .PATCH,
            body: updateBodyData,
            config: config,
            bearer: token,
            additionalHeaders: ["Prefer": "return=minimal"]
        )

        return MessageEnvelopeDTO(data: message)
    }

    private func getFavoritesWithSupabase(token: String) async throws -> FavoritesEnvelopeDTO {
        guard let currentUserID = decodeJWTSubject(token) else {
            throw APIError(message: "Unable to resolve current user session.")
        }

        let config = try loadSupabaseConfig()
        let favoritesURL = try restURL(
            config: config,
            table: "favorites",
            queryItems: [
                URLQueryItem(name: "select", value: "car_id"),
                URLQueryItem(name: "user_id", value: "eq.\(currentUserID)")
            ]
        )
        let (data, _) = try await executeSupabaseRequest(
            url: favoritesURL,
            method: .GET,
            body: nil,
            config: config,
            bearer: token
        )
        let rows = try decoder.decode([FavoriteDTO].self, from: data)
        return FavoritesEnvelopeDTO(data: rows)
    }

    private func setFavoriteWithSupabase(token: String, carID: String, isFavorite: Bool) async throws {
        guard let currentUserID = decodeJWTSubject(token) else {
            throw APIError(message: "Unable to resolve current user session.")
        }

        let config = try loadSupabaseConfig()
        if isFavorite {
            let insertPayload: [String: Any] = [
                "car_id": carID,
                "user_id": currentUserID
            ]
            let insertBody = try JSONSerialization.data(withJSONObject: insertPayload)
            let insertURL = try restURL(config: config, table: "favorites")
            do {
                _ = try await executeSupabaseRequest(
                    url: insertURL,
                    method: .POST,
                    body: insertBody,
                    config: config,
                    bearer: token,
                    additionalHeaders: ["Prefer": "resolution=merge-duplicates,return=minimal"]
                )
            } catch let apiError as APIError where apiError.statusCode == 409 {
                // Favorite already exists.
                return
            }
            return
        }

        let deleteURL = try restURL(
            config: config,
            table: "favorites",
            queryItems: [
                URLQueryItem(name: "car_id", value: "eq.\(carID)"),
                URLQueryItem(name: "user_id", value: "eq.\(currentUserID)")
            ]
        )
        _ = try await executeSupabaseRequest(
            url: deleteURL,
            method: .DELETE,
            body: nil,
            config: config,
            bearer: token,
            additionalHeaders: ["Prefer": "return=minimal"]
        )
    }

    private func decodeJWTSubject(_ token: String) -> String? {
        let parts = token.split(separator: ".")
        guard parts.count > 1 else { return nil }
        guard let payloadData = decodeBase64URL(String(parts[1])) else { return nil }
        guard let json = try? JSONSerialization.jsonObject(with: payloadData) as? [String: Any] else { return nil }
        return json["sub"] as? String
    }

    private func decodeBase64URL(_ value: String) -> Data? {
        var base64 = value
            .replacingOccurrences(of: "-", with: "+")
            .replacingOccurrences(of: "_", with: "/")
        let remainder = base64.count % 4
        if remainder > 0 {
            base64 += String(repeating: "=", count: 4 - remainder)
        }
        return Data(base64Encoded: base64)
    }

    private func restURL(config: SupabaseConfig, table: String, queryItems: [URLQueryItem] = []) throws -> URL {
        guard var components = URLComponents(string: "\(config.url)/rest/v1/\(table)") else {
            throw APIError(message: "Invalid Supabase URL")
        }
        if !queryItems.isEmpty {
            components.queryItems = queryItems
        }
        guard let url = components.url else {
            throw APIError(message: "Invalid Supabase request URL")
        }
        return url
    }

    private func inFilterValues(_ values: [String]) -> String {
        values
            .filter { !$0.isEmpty }
            .map { $0.replacingOccurrences(of: ",", with: "") }
            .joined(separator: ",")
    }

    private func request<T: Decodable, U: Encodable>(
        path: String,
        method: HTTPMethod,
        body: U?,
        baseURL: String,
        token: String?
    ) async throws -> T {
        let normalized = normalizeBaseURL(baseURL)
        guard let url = URL(string: normalized + path) else {
            throw APIError(message: "Invalid API URL")
        }

        var request = URLRequest(url: url)
        request.httpMethod = method.rawValue
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("application/json", forHTTPHeaderField: "Accept")

        if let token, !token.isEmpty {
            request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        }

        if let body {
            request.httpBody = try encoder.encode(AnyEncodable(body))
        }

        let (data, response) = try await session.data(for: request)
        guard let http = response as? HTTPURLResponse else {
            throw APIError(message: "Invalid server response")
        }

        if !(200...299).contains(http.statusCode) {
            let message =
                decodeError(
                    from: data,
                    statusCode: http.statusCode,
                    contentType: http.value(forHTTPHeaderField: "Content-Type")
                ) ?? "Request failed with status \(http.statusCode)"
            throw APIError(message: message, statusCode: http.statusCode)
        }

        do {
            return try decoder.decode(T.self, from: data)
        } catch {
            throw APIError(message: "Unable to decode server response")
        }
    }

    private func requestJSON<T: Decodable>(
        path: String,
        method: HTTPMethod,
        json: [String: Any],
        baseURL: String,
        token: String?
    ) async throws -> T {
        let normalized = normalizeBaseURL(baseURL)
        guard let url = URL(string: normalized + path) else {
            throw APIError(message: "Invalid API URL")
        }

        var request = URLRequest(url: url)
        request.httpMethod = method.rawValue
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("application/json", forHTTPHeaderField: "Accept")

        if let token, !token.isEmpty {
            request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        }

        request.httpBody = try JSONSerialization.data(withJSONObject: json)

        let (data, response) = try await session.data(for: request)
        guard let http = response as? HTTPURLResponse else {
            throw APIError(message: "Invalid server response")
        }

        if !(200...299).contains(http.statusCode) {
            let message =
                decodeError(
                    from: data,
                    statusCode: http.statusCode,
                    contentType: http.value(forHTTPHeaderField: "Content-Type")
                ) ?? "Request failed with status \(http.statusCode)"
            throw APIError(message: message, statusCode: http.statusCode)
        }

        do {
            return try decoder.decode(T.self, from: data)
        } catch {
            throw APIError(message: "Unable to decode server response")
        }
    }

    private func decodeError(from data: Data, statusCode: Int, contentType: String? = nil) -> String? {
        let normalizedContentType = contentType?.lowercased() ?? ""
        if normalizedContentType.contains("text/html") {
            if statusCode == 404 {
                return "Server route not found (404). Deploy latest API routes."
            }
            return "Server returned an HTML error page (status \(statusCode))."
        }

        if let envelope = try? decoder.decode(APIErrorEnvelope.self, from: data), let message = envelope.message, !message.isEmpty {
            return message
        }
        if let supabaseError = try? decoder.decode(SupabaseAuthErrorEnvelope.self, from: data) {
            if let msg = supabaseError.msg, !msg.isEmpty {
                return msg
            }
            if let description = supabaseError.error_description, !description.isEmpty {
                return description
            }
            if let error = supabaseError.error, !error.isEmpty {
                return error
            }
        }
        if let plain = String(data: data, encoding: .utf8) {
            let trimmed = plain.trimmingCharacters(in: .whitespacesAndNewlines)
            if trimmed.isEmpty {
                return nil
            }
            let lowered = trimmed.lowercased()
            if lowered.contains("<!doctype html") || lowered.contains("<html") || lowered.contains("<head") || lowered.contains("<body") {
                if statusCode == 404 {
                    return "Server route not found (404). Deploy latest API routes."
                }
                return "Server returned an HTML error page (status \(statusCode))."
            }
            return String(trimmed.prefix(240))
        }
        return nil
    }

    private func normalizeBaseURL(_ value: String) -> String {
        var trimmed = value.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmed.hasSuffix("/") {
            trimmed.removeLast()
        }
        if var components = URLComponents(string: trimmed), let host = components.host?.lowercased(), host == "hayamegh.com" {
            components.host = "www.hayamegh.com"
            if let normalized = components.string {
                return normalized
            }
        }
        return trimmed
    }
}

enum StringOrBoolOrNumber: Decodable {
    case string(String)
    case bool(Bool)
    case int(Int)
    case double(Double)
    case null

    init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        if container.decodeNil() {
            self = .null
        } else if let value = try? container.decode(Bool.self) {
            self = .bool(value)
        } else if let value = try? container.decode(Int.self) {
            self = .int(value)
        } else if let value = try? container.decode(Double.self) {
            self = .double(value)
        } else if let value = try? container.decode(String.self) {
            self = .string(value)
        } else {
            self = .null
        }
    }
}

enum DoubleOrIntOrString: Decodable {
    case double(Double)
    case int(Int)
    case string(String)
    case null

    init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        if container.decodeNil() {
            self = .null
        } else if let value = try? container.decode(Double.self) {
            self = .double(value)
        } else if let value = try? container.decode(Int.self) {
            self = .int(value)
        } else if let value = try? container.decode(String.self) {
            self = .string(value)
        } else {
            self = .null
        }
    }

    var doubleValue: Double {
        switch self {
        case .double(let value):
            return value
        case .int(let value):
            return Double(value)
        case .string(let value):
            return Double(value) ?? 0
        case .null:
            return 0
        }
    }

    var intValue: Int {
        Int(doubleValue.rounded())
    }
}
