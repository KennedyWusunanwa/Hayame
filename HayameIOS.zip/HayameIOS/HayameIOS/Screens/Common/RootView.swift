import SwiftUI

struct RootView: View {
    @EnvironmentObject private var appState: AppState

    var body: some View {
        Group {
            if appState.hasAppAccess {
                if appState.currentUser.role == .admin {
                    AdminShellScreen()
                } else if appState.isAuthenticated && appState.isHostApproved {
                    HostTabShell()
                } else {
                    RenterTabShell()
                }
            } else {
                AuthFlowScreen()
            }
        }
        .background(HayameTheme.pageBackground.ignoresSafeArea())
    }
}
